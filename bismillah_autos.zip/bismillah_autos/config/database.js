module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'bismillah_autos'
    }
}